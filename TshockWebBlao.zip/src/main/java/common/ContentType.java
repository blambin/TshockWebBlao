package common;

public class ContentType {

	public final static int AddServer = 1;  //添加服务器页面
	
	public final static int ServerDetail = 2; //服务器详情页面
	
	public final static int ServerBaseCommand = 3; //服务器基本命令
}
