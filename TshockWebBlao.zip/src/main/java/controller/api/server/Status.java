package controller.api.server;

import org.springframework.stereotype.Controller;

@Controller
public class Status {

}
