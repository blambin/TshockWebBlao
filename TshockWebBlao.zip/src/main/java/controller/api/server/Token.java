package controller.api.server;

public class Token {

}
