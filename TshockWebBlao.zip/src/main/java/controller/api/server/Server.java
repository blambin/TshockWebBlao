package controller.api.server;

public class Server {

}
